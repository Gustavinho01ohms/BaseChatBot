const express = require('express');
const axios = require('axios');
const path = require('path');
const io = require('socket.io-client'); // Cliente WebSocket

const app = express();
const port = 3000;

// Conecta-se ao servidor WebSocket Python
const socket = io('http://localhost:5000');

// Configura o Express para servir arquivos estáticos
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Rota para enviar a mensagem ao servidor Python
app.post('/send-message', async (req, res) => {
  const message = req.body.message;

  try {
    // Envia a mensagem para o servidor Python
    await axios.post('http://localhost:5000/receive-message', { message });
    res.send('Mensagem enviada com sucesso!');
  } catch (error) {
    res.status(500).send('Erro ao enviar a mensagem.');
  }
});

// Escuta a resposta do servidor Python via WebSocket
socket.on('response_message', (data) => {
  console.log('Mensagem do Python: ', data.message);
  // Exibe a mensagem recebida no console do Node.js
});

// Inicia o servidor Express
app.listen(port, () => {
  console.log(`Servidor Node.js rodando em http://localhost:${port}`);
});
