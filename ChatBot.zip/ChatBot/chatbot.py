from flask import Flask, request
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app)


# Rota para receber a mensagem do Node.js
@app.route('/receive-message', methods=['POST'])
def receive_message():
    print("Recebendo a mensagem...")  # Log para depuração
    data = request.json
    message = data['message']
    print(f"Mensagem recebida: {message}")

    # Verificando se o SocketIO está funcionando
    if socketio.server.eio:
        print("SocketIO está funcionando, enviando a resposta...")
        # Envia uma mensagem de volta para o Node.js via WebSocket
        socketio.emit('response_message', {'message': 'Mensagem recebida com sucesso!'})
    else:
        print("Erro: Não foi possível conectar ao SocketIO.")

    return "Mensagem recebida com sucesso!"


if __name__ == '__main__':
    # Inicia o servidor Flask com SocketIO
    socketio.run(app, port=5000, allow_unsafe_werkzeug=True)
